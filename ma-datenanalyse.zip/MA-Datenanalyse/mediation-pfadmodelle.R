# Fortgeschrittene Datenanalyse, Institut für Publizistik, JGU Mainz
# 2025-03-12

## Pakete und Daten

library(mediation)
library(lavaan)

library(tidyverse)
library(report)
theme_set(theme_minimal())

d_zeitung <- haven::read_sav("data/zeitungsnutzung_mediation.sav") |>
  haven::zap_labels()
d_zeitung

d_influencer <- haven::read_sav("data/influencer_mediation.sav") |>
  haven::zap_labels()
d_influencer

## Regressionsbasierte Analyse

d_zeitung |>
  select(Zeitungsnutzungsdauer, PolWiss, PolInt) |>
  report::report_table()

model_total <- lm(PolWiss ~ Zeitungsnutzungsdauer, data = d_zeitung)
report::report_table(model_total)

model_a <- lm(PolInt ~ Zeitungsnutzungsdauer, data = d_zeitung)
report::report_table(model_a)

model_bc <- lm(PolWiss ~ Zeitungsnutzungsdauer + PolInt, data = d_zeitung)
report::report_table(model_bc)

mediation::mediate(model_a, model_bc,
  treat = "Zeitungsnutzungsdauer",
  mediator = "PolInt",
  boot = TRUE
) |>
  summary()

## Pfadanalyse

simple_model <- "
  PolInt ~ Zeitungsnutzungsdauer
  PolWiss ~ PolInt + Zeitungsnutzungsdauer
"

results_simple <- lavaan::sem(model = simple_model, data = d_zeitung)
summary(results_simple, standardized = TRUE, rsquare = TRUE)

med_model <- "
  # Regressionen
  PolInt ~ a * Zeitungsnutzungsdauer
  PolWiss ~ b * PolInt + c * Zeitungsnutzungsdauer

  # abgeleitete Parameter
  indirect := a * b
  total := indirect + c
  prop_mediated := indirect / total
"

results_med <- lavaan::sem(
  model = med_model, data = d_zeitung,
  se = "bootstrap", bootstrap = 1000
)
summary(results_med, standardized = TRUE, rsquare = TRUE)

report::report_table(results_med) |>
  filter(Coefficient != "")

d_influencer |>
  report::report_table()

multmed_model <- "
  # Regressionen
  PW_UEBERZEUGEN ~ a1 * Werbekennzeichnung
  PW_TAEUSCHEN ~ a2 * Werbekennzeichnung
  Reaktanz ~ b1 * PW_UEBERZEUGEN + b2 * PW_TAEUSCHEN + c * Werbekennzeichnung

  # Korrelation der Mediatoren
  PW_UEBERZEUGEN ~~ PW_TAEUSCHEN

  # abgeleitete Parameter
  indirect1 := a1 * b1
  indirect2 := a2 * b2
  total := indirect1 + indirect2  + c
"

results_multmed <- lavaan::sem(
  model = multmed_model, data = d_influencer,
  se = "bootstrap", bootstrap = 1000
)
summary(results_multmed, standardized = TRUE, rsquare = TRUE)

report_table(results_multmed) |>
  filter(Coefficient != "")

## Gibt es überhaupt einen Effekt?

