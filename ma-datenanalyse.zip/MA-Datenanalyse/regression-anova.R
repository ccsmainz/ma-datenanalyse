# Fortgeschrittene Datenanalyse, Institut für Publizistik, JGU Mainz
# 2025-03-12

## Pakete und Daten

library(marginaleffects)
library(tidyverse)
library(report)
theme_set(theme_minimal())

d_pp <- haven::read_sav("data/productplacement_anova.sav") |>
  mutate(Placementhäufigkeit = as_factor(Placementhäufigkeit))
d_pp

d_wahl <- haven::read_sav("data/wahlabsicht_regression.sav") |>
  mutate(Sex = as_factor(Sex)) |>
  haven::zap_labels()
d_wahl

## ANOVA

d_pp |>
  group_by(Placementhäufigkeit) |>
  summarise(
    M = mean(Persuasionswissen, na.rm = TRUE),
    SD = sd(Persuasionswissen, na.rm = TRUE),
    n = n()
  )

results_aov_pp <- aov(Persuasionswissen ~ Placementhäufigkeit, data = d_pp)

results_aov_pp |>
  report::report_table()

results_aov_pp |>
  marginaleffects::avg_comparisons(
    variables = list(Placementhäufigkeit = "pairwise"),
    p_adjust = "bonferroni"
  ) |>
  as_tibble()

results_aov_pp |>
  marginaleffects::avg_predictions(variables = "Placementhäufigkeit") |>
  as_tibble()

results_aov_pp |>
  marginaleffects::avg_predictions(variables = "Placementhäufigkeit") |>
  as_tibble() |>
  ggplot(aes(
    x = Placementhäufigkeit, y = estimate,
    ymin = conf.low, ymax = conf.high
  )) +
  geom_pointrange() +
  labs(x = "Placementhäufigkeit", y = "Vorhergesagtes Persuasionswissen")

## Regression

results_lm_pp <- lm(Persuasionswissen ~ Placementhäufigkeit, data = d_pp)

results_lm_pp |>
  summary()

results_lm_pp |>
  report::report_table()

results_lm_pp |>
  marginaleffects::avg_predictions(variables = "Placementhäufigkeit") |>
  as_tibble()

results_wahl_1 <- lm(
  Wahlabsicht ~ Sex + Bildung + Einkommen +
    PolitischeWertorientierung + Wirksamkeitserwartung,
  data = d_wahl
)
results_wahl_1 |>
  report::report_table()

results_wahl_2 <- lm(
  Wahlabsicht ~ Sex + Bildung + Einkommen +
    PolitischeWertorientierung + Wirksamkeitserwartung +
    Qualitätsmedien + Boulevardmedien,
  data = d_wahl
)
results_wahl_2 |>
  report::report_table()

anova(results_wahl_1, results_wahl_2)

checks <- performance::check_model(results_wahl_2, panel = F)
plot(checks)

results_wahl_2 |>
  marginaleffects::avg_predictions(variables = "Boulevardmedien") |>
  as_tibble()

results_wahl_2 |>
  marginaleffects::avg_predictions(variables = "Boulevardmedien") |>
  as_tibble() |>
  ggplot(aes(
    x = Boulevardmedien, y = estimate,
    ymin = conf.low, ymax = conf.high
  )) +
  geom_line() +
  geom_ribbon(alpha = .1) +
  labs(x = "Nutzungshäufigkeit Boulevardmedien", y = "Vorhergesagte Wahlabsicht")

