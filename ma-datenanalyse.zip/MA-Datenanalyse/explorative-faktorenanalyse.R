# Fortgeschrittene Datenanalyse, Institut für Publizistik, JGU Mainz
# 2025-03-12

## Pakete und Daten

library(psych)
library(tidyverse)
library(report)

d_habit <- readxl::read_excel("data/gewohnheiten.xlsx")
d_habit

## Überprüfung der Items

d_efa <- d_habit |>
  select(c_srhi_r1:c_srhi_c2)

d_efa |>
  report::report_table()

d_efa |>
  cor(use = "complete.obs") |>
  round(2)

psych::cortest.bartlett(d_efa)

psych::KMO(d_efa)

## Explorative Faktorenanalyse

psych::fa.parallel(d_efa, fa = "fa", fm = "pa")

psych::scree(d_efa, pc = F)

results_efa <- d_efa %>%
  fa(
    nfactors = 3,
    fm = "pa",
    rotate = "oblimin"
  )

# Output anpassen
print(results_efa,
  digits = 2, ## auf 2 Nachkommastellen runden
  sort = TRUE ## Items zu den Faktoren sortieren
)

print(results_efa,
  digits = 2, ## auf 2 Nachkommastellen runden
  cut = .3, ## Ladungen unter .3 nicht anzeigen
  sort = TRUE
) ## Items zu den Faktoren sortieren

psych::fa.diagram(results_efa)

## Exkurs: Hauptkomponentenanalyse

d_informell <- haven::read_sav("data/InfKomm.sav") |>
  haven::zap_labels()

d_pca <- d_informell |>
  select(F201_01:F201_52)

d_pca |>
  report::report_table()

# F201_01: Informelle Kommunikation ist ein Mittel, mit dem ich Spannungen und Stress abbauen kann.
# F201_02: Ich nutze informelle Kommunikation, um eine Pause zu machen und mich zu erholen.
# F201_03: Informelle Kommunikation hilft mir, meinem Ärger Luft zu machen, wenn mich etwas stört.
# F201_05: Informelle Kommunikation bietet mir Abwechslung vom Arbeitsalltag.
# F201_07: Ich nutze informelle Kommunikation, um mich von der Arbeit abzulenken.
# F201_08: Ich nutze informelle Kommunikation zur Unterhaltung.
# F201_13: Durch informelle Kommunikation fühle ich mich mit meinen Kolleg:innen verbunden.
# F201_15: Durch informelle Kommunikation fühle ich mich weniger einsam.
# F201_16: Durch informelle Kommunikation fühle ich mich sozial zugehörig.
# F201_17: Informelle Kommunikation hilft mir dabei, meine Kolleg:innen privat besser kennenzulernen.
# F201_18: Durch informelle Kommunikation kann ich Freundschaften schließen.
# F201_20: Informelle Kommunikation hilft mir dabei, Bekanntschaften zu knüpfen.
# F201_25: Durch informelle Kommunikation erhalte ich Informationen, die mir helfen, meine Arbeit zu erledigen.
# F201_26: Informelle Kommunikation liefert zusätzliche Informationen zu der formellen Kommunikation in der Organisation.
# F201_27: Informelle Kommunikation informiert mich über aktuelle Ereignisse und bevorstehende Veränderungen im Unternehmen.
# F201_29: Informelle Kommunikation hilft mir, mich persönlich in mein Team einzufinden.
# F201_30: Durch informelle Kommunikation fühle ich mich der Organisation zugehörig.
# F201_31: Durch informelle Kommunikation habe ich das Gefühl, dass ich ein geschätztes Mitglied der Organisation bin.
# F201_41: Für mich ist die informelle Kommunikation eine Möglichkeit, berufliche Beziehungen zu meinen Kolleg:innen aufzubauen und zu pflegen.
# F201_42: Informelle Kommunikation unterstützt mich dabei, ein berufliches Netzwerk aufzubauen.
# F201_44: Informelle Kommunikation hilft mir und meinem Team zusammenzuwachsen.
# F201_45: Informelle Kommunikation hilft dabei, den Arbeitsalltag im Team zu organisieren.
# F201_47: Informelle Kommunikation erleichtert die Koordination und Planung von Teamarbeit.
# F201_48: Durch informelle Kommunikation fällt es leichter, gemeinsam Probleme zu lösen.
# F201_49: Informelle Kommunikation kann dabei helfen, die Organisationskultur gemeinsam zu entwickeln.
# F201_51: Informelle Kommunikation hilft mir, die Organisation zu verstehen, einschließlich ihrer Mission, Vision, Werte, Überzeugungen und Ziele.
# F201_52: Durch informelle Kommunikation entsteht ein positives Arbeitsklima.

psych::fa.parallel(d_pca, fa = "pc", fm = "pa")
psych::scree(d_pca, fa = F)

results_pca <- d_pca %>%
  principal(
    nfactors = 4,
    rotate = "oblimin"
  )

# Output anpassen
print(results_pca,
  digits = 2, ## auf 2 Nachkommastellen runden
  cut = .3, ## Ladungen unter .3 nicht anzeigen
  sort = TRUE ## Items zu den Komponenten sortieren
)

scores <- results_pca$scores # Scores extrahieren

d_pca <- cbind(d_pca, scores) # an den Datensatz binden

