# Fortgeschrittene Datenanalyse, Institut für Publizistik, JGU Mainz
# 2025-03-12

## Pakete und Daten

library(lavaan)
library(tidyverse)
library(report)

d_habit <- readxl::read_excel("data/gewohnheiten.xlsx")
d_habit |>
  select(starts_with("f_srhi_r"))

srhi_model <- "
   f_srhi =~ f_srhi_r1 + f_srhi_r2 + f_srhi_r3
"
cfa_basic <- cfa(srhi_model, data = d_habit)
summary(cfa_basic, standardized = TRUE)

## Parameter-Gleichsetzung

srhi_model_con <- "
   f_srhi =~ f_srhi_r1 + f_srhi_r2 + f_srhi_r3
"
cfa_con <- cfa(srhi_model_con, data = d_habit, std.lv = TRUE)
summary(cfa_con, standardized = TRUE)

srhi_model_tau <- "
   f_srhi =~ lambda*f_srhi_r1 + lambda*f_srhi_r2 + lambda*f_srhi_r3
"
cfa_tau <- cfa(srhi_model_tau, data = d_habit, std.lv = TRUE)
summary(cfa_tau, fit.measures = TRUE, standardized = TRUE)

anova(cfa_con, cfa_tau)

## Invarianztests über Gruppen

cfa_config <- cfa(srhi_model, data = d_habit, group = "p_2")
summary(cfa_config, fit.measures = TRUE, standardized = TRUE)

cfa_metric <- cfa(srhi_model,
  data = d_habit, group = "p_2",
  group.equal = c("loadings")
)
summary(cfa_metric, fit.measures = TRUE, standardized = TRUE)

anova(cfa_config, cfa_metric)

cfa_scalar <- cfa(srhi_model,
  data = d_habit, group = "p_2",
  group.equal = c("loadings", "intercepts")
)
summary(cfa_scalar, fit.measures = TRUE, standardized = TRUE)

anova(cfa_metric, cfa_scalar)

