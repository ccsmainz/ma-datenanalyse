# Fortgeschrittene Datenanalyse, Institut für Publizistik, JGU Mainz
# 2025-03-12

## Pakete und Daten

library(lme4)
library(marginaleffects)
library(tidyverse)
library(report)
theme_set(theme_minimal())

d_zoizner <- read_csv("data/zoizner_etal.csv")
d_zoizner

count(d_zoizner, dCountry_W2)

d_zoizner |>
  select(cross_cutting_consumption_w2_01) |>
  report::report_sample()

## Nullmodell und ICC

m0_cc <- lmer(cross_cutting_consumption_w2_01 ~ 1 + (1 | dCountry_W2), d_zoizner)

performance::icc(m0_cc)

marginaleffects::avg_predictions(m0_cc, by = "dCountry_W2") |>
  as_tibble()

marginaleffects::avg_predictions(m0_cc, by = "dCountry_W2") |>
  as_tibble() |>
  ggplot(aes(
    x = reorder(dCountry_W2, estimate), y = estimate,
    ymin = conf.low, ymax = conf.high
  )) +
  geom_pointrange() +
  coord_flip() +
  labs(x = "", y = "Predicted cross-cutting exposure")

## Varying Intercepts

m1_cc <- lmer(cross_cutting_consumption_w2_01 ~ cross_cutting_consumption_w1_01 + worried_from_covid_total_01 +
  (1 | dCountry_W2), d_zoizner)
report::report_table(m1_cc)

avg_predictions(m1_cc, variables = c("worried_from_covid_total_01", "dCountry_W2")) |>
  as_tibble()

avg_predictions(m1_cc, variables = c("worried_from_covid_total_01", "dCountry_W2")) |>
  as_tibble() |>
  ggplot(aes(
    x = worried_from_covid_total_01, y = estimate,
    color = dCountry_W2, group = dCountry_W2
  )) +
  geom_line(show.legend = FALSE) +
  labs(x = "Covid-related worries T1", y = "Predicted cross-cutting exposure")

checks <- performance::check_model(m1_cc, panel = F)
plot(checks)

## Varying Slopes

m2_cc <- lmer(cross_cutting_consumption_w2_01 ~ cross_cutting_consumption_w1_01 + worried_from_covid_total_01 +
  (1 + cross_cutting_consumption_w1_01 + worried_from_covid_total_01 | dCountry_W2), d_zoizner)
report::report_table(m2_cc)

marginaleffects::avg_slopes(m2_cc, variables = "worried_from_covid_total_01", by = "dCountry_W2") |>
  as_tibble()

avg_predictions(m2_cc, variables = c("worried_from_covid_total_01", "dCountry_W2")) |>
  as_tibble() |>
  ggplot(aes(
    x = worried_from_covid_total_01, y = estimate,
    color = dCountry_W2, group = dCountry_W2
  )) +
  geom_line(show.legend = FALSE) +
  labs(x = "Covid-related worries T1", y = "Predicted cross-cutting exposure")

anova(m1_cc, m2_cc)

## Level-2 Prädiktoren

m3_cc <- lmer(cross_cutting_consumption_w2_01 ~ cross_cutting_consumption_w1_01 + worried_from_covid_total_01 + confirmed_per_100k + (1 + cross_cutting_consumption_w1_01 + worried_from_covid_total_01 | dCountry_W2), d_zoizner)
report::report_table(m3_cc)

