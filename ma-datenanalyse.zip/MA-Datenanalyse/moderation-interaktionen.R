# Fortgeschrittene Datenanalyse, Institut für Publizistik, JGU Mainz
# 2025-03-12

## Pakete und Daten

library(marginaleffects)
library(tidyverse)
library(report)
theme_set(theme_minimal())

d_pp2 <- haven::read_sav("data/productplacement_moderation.sav") |>
  mutate(
    Placementhäufigkeit = as_factor(Placementhäufigkeit) |> fct_drop(),
    Involvement = as_factor(Involvement)
  ) |>
  haven::zap_labels() |>
  select(-onefaktor)
d_pp2

## Kategorieller Moderator

d_pp2 |>
  group_by(Placementhäufigkeit, Involvement) |>
  summarise(
    M = mean(Störempfinden, na.rm = TRUE),
    SD = sd(Störempfinden, na.rm = TRUE),
    n = n()
  )

results_aov_involve <- aov(Störempfinden ~ Placementhäufigkeit * Involvement, data = d_pp2)
report::report_table(results_aov_involve)

results_involve <- lm(Störempfinden ~ Placementhäufigkeit * Involvement, data = d_pp2)
report::report_table(results_involve)

marginaleffects::avg_slopes(results_involve) |>
  as_tibble()

lm(Störempfinden ~ Placementhäufigkeit + Involvement, data = d_pp2) |>
  report::report_table()

marginaleffects::avg_slopes(results_involve,
  variables = "Placementhäufigkeit", by = "Involvement"
) |>
  as_tibble()

marginaleffects::avg_predictions(results_involve,
  variables = c("Placementhäufigkeit", "Involvement")
) |>
  as_tibble()

marginaleffects::avg_predictions(results_involve,
  variables = c("Placementhäufigkeit", "Involvement")
) |>
  as_tibble() |>
  ggplot(aes(
    x = Placementhäufigkeit, y = estimate,
    ymin = conf.low, ymax = conf.high,
    group = Involvement, color = Involvement
  )) +
  geom_pointrange(position = position_dodge(.5)) +
  geom_line(position = position_dodge(.5)) +
  labs(y = "Vorhergesagtes Störempfinden")

## Metrischer Moderator

results_bekannt <- lm(Störempfinden ~ Placementhäufigkeit * Bekanntheit, data = d_pp2)
report::report_table(results_bekannt)

marginaleffects::avg_slopes(results_bekannt) |>
  as_tibble()

d_pp2 <- d_pp2 |>
  mutate(Bekanntheit_c = scale(Bekanntheit, scale = F))

lm(Störempfinden ~ Placementhäufigkeit * Bekanntheit_c, data = d_pp2) |>
  report::report_table()

marginaleffects::avg_slopes(results_bekannt,
  variables = "Placementhäufigkeit", by = "Bekanntheit"
) |>
  as_tibble()

marginaleffects::avg_predictions(results_bekannt,
  variables = c("Placementhäufigkeit", "Bekanntheit")
) |>
  as_tibble() |>
  filter(Bekanntheit %in% c(1, 4)) |>
  mutate(Bekanntheit = if_else(Bekanntheit == 1, "unbekannt", "sehr bekannt")) |>
  ggplot(aes(
    x = Placementhäufigkeit, y = estimate,
    ymin = conf.low, ymax = conf.high,
    group = Bekanntheit, color = Bekanntheit
  )) +
  geom_pointrange(position = position_dodge(.5)) +
  geom_line(position = position_dodge(.5)) +
  labs(y = "Vorhergesagtes Störempfinden", color = "Bekanntheit des Produkts")

