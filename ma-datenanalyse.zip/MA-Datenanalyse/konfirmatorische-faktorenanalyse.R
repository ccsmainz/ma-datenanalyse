# Fortgeschrittene Datenanalyse, Institut für Publizistik, JGU Mainz
# 2025-03-12

## Pakete und Daten

library(lavaan)
library(semTools)
library(tidyverse)
library(report)

d_habit <- readxl::read_excel("data/gewohnheiten.xlsx")
d_habit

## Überprüfung der Items

d_cfa <- d_habit |>
  select(c_srhi_r1:c_srhi_c2)

d_cfa |>
  report::report_table()

d_cfa |>
  psych::mardia(plot = FALSE) # Wir sollten MLR anstelle von ML verwenden.

## Modellschätzung

cfa_model <- "
   repetition =~ c_srhi_r1 + c_srhi_r2 + c_srhi_r3
   automatism =~ c_srhi_a1 + c_srhi_a2 + c_srhi_a3 + c_srhi_a4 + c_srhi_a5 + c_srhi_a6
   control =~ c_srhi_c1 + c_srhi_c2
"

cfa_results <- lavaan::cfa(cfa_model, data = d_cfa)

summary(cfa_results, fit = TRUE, std = TRUE)

## Fit-Indizes für die CFA

## Modellverbesserung

cfa_model2 <- "
   repetition =~ c_srhi_r1 + c_srhi_r2 + c_srhi_r3
   automatism =~ c_srhi_a1 + c_srhi_a2 + c_srhi_a3 + c_srhi_a5 + c_srhi_a6
   control =~ c_srhi_c1 + c_srhi_c2
"

cfa_results2 <- lavaan::cfa(cfa_model2, data = d_cfa)
summary(cfa_results2, fit = T, std = T)

lavaan::modificationindices(cfa_results2) |>
  arrange(desc(mi)) |>
  head(5)

## Reliablität

semTools::reliability(cfa_results2)

