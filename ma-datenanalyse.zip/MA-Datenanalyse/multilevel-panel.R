# Fortgeschrittene Datenanalyse, Institut für Publizistik, JGU Mainz
# 2025-03-12

## Pakete und Daten

library(plm)
library(lme4)
library(marginaleffects)

library(tidyverse)
library(report)
theme_set(theme_minimal())

d_johannes <- read_rds("data/johannes_etal.rds") |>
  filter(wave >= 2) |>
  filter(!is.na(tv_time))
d_johannes

n_distinct(d_johannes$id)

d_johannes |>
  select(wave, life_satisfaction, tv_time, gender) |>
  report::report_table()

## OLS Modelle

results_ols <- lm(life_satisfaction ~ tv_time, data = d_johannes)
report::report_table(results_ols)

d_johannes <- d_johannes |>
  group_by(id) |>
  mutate(tv_time_within = tv_time - mean(tv_time, na.rm = TRUE))

results_fe_demean <- lm(life_satisfaction ~ -1 + tv_time_within, d_johannes)
report::report_table(results_fe_demean)

results_fe <- plm::plm(life_satisfaction ~ tv_time, index = "id", data = d_johannes, model = "within")
summary(results_fe)

results_fe_gender <- plm::plm(life_satisfaction ~ tv_time + gender, data = d_johannes, model = "within", index = "id")
summary(results_fe_gender)

## Multilevel-Modelle

results_re <- lme4::lmer(life_satisfaction ~ tv_time + (1 | id), data = d_johannes)
report::report_table(results_re)

results_re_gender <- lme4::lmer(life_satisfaction ~ tv_time + gender + (1 | id), data = d_johannes)
report::report_table(results_re_gender)

d_johannes <- d_johannes |>
  group_by(id) |>
  mutate(
    tv_time_between = mean(tv_time, na.rm = TRUE)
  )

results_rewb <- lme4::lmer(life_satisfaction ~ tv_time_within + tv_time_between + (1 | id), data = d_johannes)
report::report_table(results_rewb)

preds_rewb <- marginaleffects::avg_predictions(results_rewb, variables = "tv_time_within")
preds_rewb |>
  ggplot(aes(x = tv_time_within, y = estimate, ymin = conf.low, ymax = conf.high)) +
  geom_line() +
  geom_ribbon(alpha = .1) +
  labs(x = "difference in TV use (hours per day)", y = "Predicted life satisfaction")

results_rewb_gender <- lme4::lmer(life_satisfaction ~ tv_time_within + tv_time_between + gender + (1 | id), data = d_johannes)
report::report_table(results_rewb_gender)

results_time1 <- lme4::lmer(life_satisfaction ~ wave + (1 | id), data = d_johannes)
report::report_table(results_time1)

marginaleffects::avg_predictions(results_time1, variables = c("wave")) |>
  ggplot(aes(
    x = wave, y = estimate, ymin = conf.low, ymax = conf.high,
  )) +
  geom_line() +
  geom_ribbon(alpha = .1) +
  labs(x = "Week", y = "Predicted life satisfaction")

results_time2 <- lme4::lmer(life_satisfaction ~ wave + (1 + wave | id), data = d_johannes)

anova(results_time1, results_time2)

report::report_table(results_time2)

