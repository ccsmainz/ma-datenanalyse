# Fortgeschrittene Datenanalyse, Institut für Publizistik, JGU Mainz
# 2025-03-12

## Lagged und Cross-Lagged Modelle

## Pakete und Daten

library(lavaan)
library(tidyverse)
library(report)
theme_set(theme_minimal())

d_stevic <- haven::read_sav("data/stevic_etal.sav") |>
  mutate(female_child = if_else(gender_child_w1 == 1, 1, 0)) |>
  haven::zap_labels()
d_stevic

d_stevic |>
  select(female_child, w1_nightuse_child_w1, w2_nightuse_child_w2, attention_parent_w1, attention_parent_w2) |>
  report::report_table()

## Autokorrelation, -regression und Lagged Dependent Variable (LDV)

cor.test(~ w1_nightuse_child_w1 + w2_nightuse_child_w2, d_stevic) |>
  report_table()

cor.test(~ attention_parent_w1 + attention_parent_w2, d_stevic) |>
  report::report_table()

results_naiv <- lm(attention_parent_w2 ~ w1_nightuse_child_w1, d_stevic)
report::report_table(results_naiv)

results_ldv <- lm(attention_parent_w2 ~ w1_nightuse_child_w1 + attention_parent_w1, d_stevic)
report::report_table(results_ldv)

## Interpretation des LDV-Koeffizienten

results_ldv2 <- lm(w2_nightuse_child_w2 ~ w1_nightuse_child_w1 + attention_parent_w1, d_stevic)
report::report_table(results_ldv2)

## Cross-lagged Panel Model (CLPM)

clp_model <- "
  attention_parent_w2 ~ w1_nightuse_child_w1 + attention_parent_w1
  w2_nightuse_child_w2 ~ w1_nightuse_child_w1 + attention_parent_w1

  w1_nightuse_child_w1 ~~ attention_parent_w1
"
results_clpm <- lavaan::sem(clp_model, data = d_stevic)
summary(results_clpm, standardized = TRUE, rsquare = TRUE)

clp_model_age <- "
  attention_parent_w2 ~ w1_nightuse_child_w1 + attention_parent_w1 + female_child
  w2_nightuse_child_w2 ~ w1_nightuse_child_w1 + attention_parent_w1 + female_child

  w1_nightuse_child_w1 ~ female_child
   attention_parent_w1 ~ female_child
  w1_nightuse_child_w1 ~~ attention_parent_w1
"
results_clpm_age <- lavaan::sem(clp_model_age, data = d_stevic)
summary(results_clpm_age, standardized = TRUE, rsquare = TRUE)

